package tazoria.banimo.common.utils.jwt;

import org.springframework.stereotype.Component;

@Component
public class JwtUtil {

}
